#include <vector>
#include "RestauranteCaseiro.h"

    RestauranteCaseiro::RestauranteCaseiro(std::string n){
        nome = n;
    }
    void RestauranteCaseiro::adicionaAoPedido(int numMesa, Pedido p){
        bool add = true;
        for(int i = 0; i < mesa[numMesa].pedido.size(); i++){
            if(mesa[numMesa].pedido[i].numero == p.numero){
                mesa[numMesa].pedido[i].quantidade++;
                add = false;
            }
        }
        if(add)
            mesa[numMesa].pedido.push_back(p);
    }
    float RestauranteCaseiro::calculaTotalRestaurante(){
        float total = 0;
        for(int i = 0; i < 20; i++){
            for(int j = 0; j < mesa[i].pedido.size(); j++){
                total += mesa[i].pedido[j].preco * mesa[i].pedido[j].quantidade;
            }
        }
        return total;
    }

std::string RestauranteCaseiro::getNome(){
    return nome;
}