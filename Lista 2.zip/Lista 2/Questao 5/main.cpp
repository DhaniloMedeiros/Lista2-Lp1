#include "RestauranteCaseiro.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
} 

void menuRestaurante(RestauranteCaseiro &rest){
    std::cout << "Restauranta " << rest.getNome() << std::endl;
    puts("1 - Realizar um pedido.");
    puts("2 - Operacoes com a mesa.");
    puts("3 - Calcular total do restaurante.");
    puts("4 - Finalizar programa");   
    std::cout << "\nDigite a opcao desejada:";
}

void menuMesa(){
    puts("~~~~~MENU MESA~~~~~");
    puts("1 - Realizar um pedido.");
    puts("2 - Calcular total da mesa.");
    puts("3 - Zerar pedidos.");
    std::cout << "\nDigite a opcao desejada:";
}

int main(){
    RestauranteCaseiro restaurante1 = RestauranteCaseiro("Budega do vitinho");
    Pedido pedido = Pedido();
    bool loop = true;
    
    while (loop){
        int menu;
        int num;
        limpaTela();
        menuRestaurante(restaurante1);
        std::cin >> menu;
        getchar();
        switch (menu){
            case 1:
                limpaTela();
                std::cout << "Informe o numero da mesa: ";
                std::cin >> num;
                getchar();
                std::cout << "Informe o numero do pedido: ";
                std::cin >> pedido.numero;
                getchar();
                std::cout << "Informe a descricao do pedido: ";
                getline(std::cin, pedido.descricao);
                std::cout << "Informe a quantidade do pedido: ";
                std::cin >> pedido.quantidade;
                getchar();
                std::cout << "Informe o preco do pedido: ";
                std::cin >> pedido.preco;
                getchar();
                restaurante1.adicionaAoPedido(num, pedido);
                break;
            case 2:
                limpaTela();
                menuMesa();
                std::cin >> menu;
                getchar();
                switch (menu)
                {
                    case 1:
                        limpaTela();
                        std::cout << "Informe o numero da mesa: ";
                        std::cin >> num;
                        getchar();
                        std::cout << "Informe o numero do pedido: ";
                        std::cin >> pedido.numero;
                        getchar();
                        std::cout << "Informe a descricao do pedido: ";
                        getline(std::cin, pedido.descricao);
                        std::cout << "Informe a quantidade do pedido: ";
                        std::cin >> pedido.quantidade;
                        getchar();
                        std::cout << "Informe o preco do pedido: ";
                        std::cin >> pedido.preco;
                        getchar();
                        restaurante1.mesa[num].adicionaAoPedido(pedido); //eh diferente do outro
                        break;
                    case 2:
                        limpaTela();
                        std::cout << "Informe o numero da mesa: ";
                        std::cin >> num;
                        getchar();
                        std::cout << "A conta da mesa " << num << " eh de R$ " << restaurante1.mesa[num].calculaTotal();
                        std::cout << "\nAperte ENTER pra continuar.";
                        getchar();
                        break;
                    case 3:
                        limpaTela();
                        std::cout << "Informe o numero da mesa: ";
                        std::cin >> num;
                        getchar();
                        restaurante1.mesa[num].zeraPedidos();
                        std::cout << "Pedidos zerados, aperte ENTER para continuar." << std::endl;
                        getchar();
                        break;
                    default:
                        limpaTela();
                        std::cout << "Opcao invalida, aperte ENTER pra voltar ao menu.";
                        getchar();
                        break;
                }
                break;
            case 3:
                limpaTela();
                std::cout << "A conta total do(a) " << restaurante1.getNome() << " eh R$ " << restaurante1.calculaTotalRestaurante();
                getchar();
                break;
            case 4:
                limpaTela();
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Opcao invalida, aperte ENTER pra voltar ao menu.";
                getchar();
                break;
        }
    }

    puts("\nFim");
    return 0;
}