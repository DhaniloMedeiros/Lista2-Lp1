#include <iostream>
#include <vector>
#include <fstream>

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

std::vector<std::string> lerArquivo(){
    std::ifstream arquivo;
    std::vector<std::string> vetorString;
    std::string str;
    
    arquivo.open("arquivoEntrada.txt");
    if(!arquivo.is_open()){
        std::cout << "Nao foi possivel abrir o arquivo.";
        return vetorString;
    }

    while (true){
        if (arquivo.eof() || arquivo.bad() || arquivo.fail())
            break;
        getline(arquivo, str);
        vetorString.push_back(str);
    }
    arquivo.close();
    return vetorString;
}

void escreverArquivo(std::vector<std::string> vetorString){
    std::ofstream arquivo;
    std::string str;

    arquivo.open("arquivoSaida.txt");
    if(!arquivo.is_open()){
        std::cout << "Nao foi possivel abrir o arquivo.";
    }

    for (int i = 0; i < vetorString.size(); i++){
        arquivo << vetorString[i] << std::endl;
    }
    arquivo.close();
}

int main(){
    std::vector<std::string> vetorString;
    limpaTela();
    std::cout << "Para testar o programa eh so alterar o arquivoEntrada \nque esta na pasta da questao";
    std::cout << " o seu input sera transferido para o aquivoSaida\n";
    vetorString = lerArquivo();
    escreverArquivo(vetorString);
    return 0;
}