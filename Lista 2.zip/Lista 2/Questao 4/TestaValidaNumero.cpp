#include "TestaValidaNumero.h"

void TestaValidaNumero::validaNumero(int num){
    if(num <= 0)
        throw ValorAbaixoException("Valor abaixo do necessario.");
    else if(num > 100 && num < 1000)
        throw ValorAcimaException("Valor acima do necessario.");
    else if(num >= 1000)
        throw ValorMuitoAcimaException("Valor muito acima do necessario.");
}