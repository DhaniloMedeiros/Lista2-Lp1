#include "TestaValidaNumero.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

int main(){
    TestaValidaNumero teste;
    bool loop = true;
    while(loop){
        limpaTela();
        int num;
        try{
            std::cout << "\nDigite um numero para validar:";
            std::cin >> num;
            getchar();
            teste.validaNumero(num);
            std::cout << "\nNumero valido!!\n";
        }
        catch(ValorAcimaException er){
            std::cout << std::endl << er.getError() << std::endl;
        }
        catch(ValorMuitoAcimaException er){
            std::cout << std::endl << er.getError() << std::endl;
        }
        catch(ValorAbaixoException er){
            std::cout << std::endl << er.getError() << std::endl;
        }
        std::cout << "\nDigite 0 pra testar outro numero ou 1 para encerrar:";
        std::cin >> num;
        getchar();
        switch (num){
        case 0:
            break;
        case 1:
            loop = false;
            break;
        default:
            break;
        }
    }
    
    return 0;
}