#include "ValorMuitoAcimaException.h"

ValorMuitoAcimaException::ValorMuitoAcimaException(std::string err){
    error = err;
}
std::string ValorMuitoAcimaException::getError(){
    return error;
}