#pragma once
#include <iostream>

class ValorAcimaException
{
private:
    std::string error;
public:
    std::string getError();
    ValorAcimaException(std::string err);
};
