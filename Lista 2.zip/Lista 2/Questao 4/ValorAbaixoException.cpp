#include "ValorAbaixoException.h"

ValorAbaixoException::ValorAbaixoException(std::string err){
    error = err;
}
std::string ValorAbaixoException::getError(){
    return error;
}