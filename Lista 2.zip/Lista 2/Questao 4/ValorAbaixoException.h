#pragma once
#include <iostream>

class ValorAbaixoException
{
private:
    std::string error;
public:
    std::string getError();
    ValorAbaixoException(std::string err);
};
