#pragma once
#include <iostream>

class ValorMuitoAcimaException
{
private:
    std::string error;
public:
    std::string getError();
    ValorMuitoAcimaException(std::string err);
};
