#include "ValorAcimaException.h"

ValorAcimaException::ValorAcimaException(std::string err){
    error = err;
}
std::string ValorAcimaException::getError(){
    return error;
}