#pragma once
#include "ValorAcimaException.h"
#include "ValorMuitoAcimaException.h"
#include "ValorAbaixoException.h"

class TestaValidaNumero
{
public:
    void validaNumero(int num);
};