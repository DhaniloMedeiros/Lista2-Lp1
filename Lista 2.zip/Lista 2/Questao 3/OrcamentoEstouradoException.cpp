#include "OrcamentoEstouradoException.h"
#include <iostream>
int OrcamentoEstouradoException::getError(){
    return error;
}
OrcamentoEstouradoException::OrcamentoEstouradoException(int err){
    error = err;
}