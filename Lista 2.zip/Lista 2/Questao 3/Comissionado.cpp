#include "Comissionado.h"

Comissionado::Comissionado(){
    vendasSemanais = 0;
    percentualComissao = 0;
}
Comissionado::Comissionado(double vs, double pc, std::string str, int mat){
    vendasSemanais = vs;
    percentualComissao = pc;
    nome = str;
    matricula = mat;
}
double Comissionado::calculaSalario(){
    return vendasSemanais * (percentualComissao/100);
}
double Comissionado::getVendasSemanais(){
    return vendasSemanais;
}
double Comissionado::getPercentualComissao(){
    return percentualComissao;
}