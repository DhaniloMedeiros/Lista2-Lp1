#pragma once
#include "Funcionario.h"

class Comissionado : public Funcionario
{
private:
    double vendasSemanais;
    double percentualComissao;
public:
    Comissionado();
    Comissionado(double vs, double pc, std::string str, int mat);
    double calculaSalario();
    double getVendasSemanais();
    double getPercentualComissao();
};
