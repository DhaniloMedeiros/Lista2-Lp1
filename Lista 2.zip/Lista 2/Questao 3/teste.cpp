#include <iostream>

int main(){

    try{
        int momsAge = 50;
        int sonsAge = 34;
        if(sonsAge > momsAge){
            throw 99;//numero do erro
        }
    }catch(int x){
        std::cout << "Son cant be older"
    }
}