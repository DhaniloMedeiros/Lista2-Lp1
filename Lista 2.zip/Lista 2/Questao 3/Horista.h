#pragma once
#include "Funcionario.h"

class Horista : public Funcionario
{
private:
    double salarioPorHora;
    double horasTrabalhadas;
public:
    Horista();
    Horista(double sph, double ht, std::string str, int mat);
    double calculaSalario();
    double getSalarioPorHora();
    double getHorasTrabalhadas();
};
