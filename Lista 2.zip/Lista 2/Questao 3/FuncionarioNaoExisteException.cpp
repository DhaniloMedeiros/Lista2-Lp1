#include "FuncionarioNaoExisteException.h"

int FuncionarioNaoExisteException::getError(){
    return error;
}
FuncionarioNaoExisteException::FuncionarioNaoExisteException(int err){
    error = err;
}