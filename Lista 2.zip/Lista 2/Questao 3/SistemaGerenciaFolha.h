#pragma once
#include "Funcionario.h"
#include "Assalariado.h"
#include "Horista.h"
#include "Comissionado.h"
#include "FuncionarioNaoExisteException.h"
#include "OrcamentoEstouradoException.h"
#include <vector>

class SistemaGerenciaFolha
{
private:
    std::vector<Funcionario*> funcionarios; 
    double orcamentoMaximo;   
public:
    SistemaGerenciaFolha(double om);
    void setFuncionarios(Funcionario *func);
    std::vector<Funcionario*> getFuncionarios();
    double calculaValorTotalFolha();
    double consultaSalarioFuncionario(std::string str);
};

