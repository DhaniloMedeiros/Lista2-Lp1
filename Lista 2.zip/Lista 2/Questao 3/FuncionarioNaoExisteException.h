#pragma once
#include <iostream>
#include <exception>
class FuncionarioNaoExisteException : public std::exception
{
private:
    int error;
public:
    int getError();
    FuncionarioNaoExisteException(int err);
};
