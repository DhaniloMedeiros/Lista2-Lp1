#include "SaldoNaoDisponivelException.h"

SaldoNaoDisponivelException::SaldoNaoDisponivelException(std::string err){
    error = err;
}
std::string SaldoNaoDisponivelException::getError(){
    return error;
}