#pragma once
#include <exception>
#include <iostream>
class SaldoNaoDisponivelException : public std::exception
{
private:
    std::string error;
public:
    SaldoNaoDisponivelException(std::string err);
    std::string getError();
};
