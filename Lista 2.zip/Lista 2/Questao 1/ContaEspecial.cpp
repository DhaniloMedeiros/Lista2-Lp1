#include "ContaEspecial.h"
void ContaEspecial::definirLimite(){//3x salario mensal
    limite = 3*salarioMensal;
}
ContaEspecial::ContaEspecial(std::string str, double sal, int nc, double sl){
    nomeCliente = str;
    salarioMensal = sal;
    numeroConta = nc;
    saldo = sl;
    definirLimite();
}
ContaEspecial::ContaEspecial(){
    nomeCliente = "NULL";
    salarioMensal = numeroConta = saldo = limite = 0;
}