#pragma once
#include "IConta.h"
#include <iostream> 

class Conta : public IConta
{
protected:
    std::string nomeCliente;
    double salarioMensal;
    int numeroConta;
    double saldo;
    double limite;
public:
    Conta();
    Conta(std::string str, double sal, int nc, double sl);
    std::string getnomeCliente();
    double getsalarioMensal();
    int getnumeroConta();
    double getsaldo();
    double getlimite();
    void setnomeCliente(std::string str);
    void setsalarioMensal(double db);
    void setnumeroConta(int i);
    void setsaldo(double saldo);
    void definirLimite();//2x salario mensal
    bool sacar(double valor);
    void depositar(double valor);
};