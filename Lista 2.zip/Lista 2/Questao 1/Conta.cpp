#include "Conta.h"

Conta::Conta(){
    nomeCliente = "NULL";
    salarioMensal = numeroConta = saldo = limite = 0;
}
Conta::Conta(std::string str, double sal, int nc, double sl){
    nomeCliente = str;
    salarioMensal = sal;
    numeroConta = nc;
    saldo = sl;
    definirLimite();
}
std::string Conta::getnomeCliente(){
    return nomeCliente;
}
double Conta::getsalarioMensal(){
    return salarioMensal;
}
int Conta::getnumeroConta(){
    return numeroConta;
}
double Conta::getsaldo(){
    return saldo;
}
double Conta::getlimite(){
    return limite;
}
void Conta::setnomeCliente(std::string str){
    nomeCliente = str;
}
void Conta::setsalarioMensal(double db){
    salarioMensal = db;
}
void Conta::setnumeroConta(int i){
    numeroConta = i;
}
void Conta::setsaldo(double saldo){
    saldo = saldo;
}
void Conta::definirLimite(){//2x salario mensal
    limite = 2*salarioMensal;
}
bool Conta::sacar(double valor){
    saldo -= valor;
    if(saldo*-1 > limite){//saque invalido
        saldo += valor;
        return false;
    }
    else
        return true;
}
void Conta::depositar(double valor){
    saldo += valor;
}