#pragma once
#include "Conta.h"

class ContaEspecial : public Conta
{   
    public: 
        ContaEspecial();
        ContaEspecial(std::string str, double sal, int nc, double sl);
        void definirLimite();//3x salario mensal
};